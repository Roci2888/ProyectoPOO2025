package org.example.Arte_Kuyen;

public class Joya extends Articulo{

    public Joya(int id, String nombre, String descripcion, int precio) {
        super(id, nombre, descripcion, precio);
    }

    public String toString() {
        return "Joya{}";
    }
}
