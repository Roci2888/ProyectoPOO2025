package org.example.Arte_Kuyen;

public class Cuadro extends Articulo{

    public Cuadro(int id, String nombre, String descripcion, int precio) {
        super(id, nombre, descripcion, precio);
    }

    @Override
    public String toString() {
        return "Cuadro{}";
    }
}
