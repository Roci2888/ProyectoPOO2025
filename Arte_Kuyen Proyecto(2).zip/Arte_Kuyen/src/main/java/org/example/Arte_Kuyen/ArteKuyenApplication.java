package org.example.Arte_Kuyen;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class ArteKuyenApplication {

    public static void main(String[] args) {
        SpringApplication.run(ArteKuyenApplication.class, args);
        ArrayList<Cuadro> cuadros = importarCuadros();
        ArrayList<Joya> joyas = importarJoyas();
        ArrayList<Mosaico> mosaicos = importarMosaicos();

        Usuario U= new Usuario("r.perez@gmail.com","1234");
    }


        private static <T> ArrayList<T> importarDatos(String nombreArchivo, Class<T> clase) {
            JsonParser jsonParser = new JsonParser();
            ArrayList<T> objetos = new ArrayList<>();

            try {
                BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
                JsonElement jsonElement = jsonParser.parse(br);

                Type tipoLista = TypeToken.getParameterized(List.class, clase).getType();
                objetos = new Gson().fromJson(jsonElement, tipoLista);

                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return objetos;
        }

        public static ArrayList<Cuadro> importarCuadros() {
            return importarDatos("cuadros.json", Cuadro.class);
        }

        public static ArrayList<Joya> importarJoyas() {
            return importarDatos("joyas.json", Joya.class);
        }

        public static ArrayList<Mosaico> importarMosaicos() {
            return importarDatos("mosaicos.json", Mosaico.class);
        }
    }


