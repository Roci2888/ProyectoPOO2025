package org.example.Arte_Kuyen.controllers;

public class BoletaController {
}
