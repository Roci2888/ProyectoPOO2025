// API Configuration
const API_BASE_URL = 'http://localhost:8080/api';

class ApiClient {
    constructor() {
        this.baseURL = API_BASE_URL;
    }

    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        };

        try {
            const response = await fetch(url, config);

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                return await response.json();
            }

            return await response.text();
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

//insertar base de datos

    async getAllProducts() {
        try {
            const response = await fetch(`${this.baseURL}/products`);
            if (!response.ok) {
                throw new Error('Error al cargar productos');
            }
            return await response.json();
        } catch (error) {
            console.error('Error:', error);
            // Fallback a datos locales si la API falla
            return this.getLocalProducts();
        }
    }

    async getProductsByCategory(category) {
        try {
            const response = await fetch(`${this.baseURL}/products/category/${category}`);
            if (!response.ok) {
                throw new Error('Error al cargar productos por categoría');
            }
            return await response.json();
        } catch (error) {
            console.error('Error:', error);
            return this.getLocalProducts().filter(product =>
                category === 'all' || product.category === category
            );
        }
    }

    async searchProducts(query) {
        try {
            const response = await fetch(`${this.baseURL}/products/search?q=${encodeURIComponent(query)}`);
            if (!response.ok) {
                throw new Error('Error en búsqueda');
            }
            return await response.json();
        } catch (error) {
            console.error('Error:', error);
            return this.getLocalProducts().filter(product =>
                product.name.toLowerCase().includes(query.toLowerCase()) ||
                product.description.toLowerCase().includes(query.toLowerCase()) ||
                product.artist.toLowerCase().includes(query.toLowerCase())
            );
        }
    }

    // Datos locales como fallback
    getLocalProducts() {
        return [
            {
                id: 1,
                name: "Mosaico Mediterráneo",
                description: "Hermoso mosaico inspirado en los colores del Mediterráneo",
                price: 85000.0,
                category: "MOSAICOS",
                artist: "María García",
                dimensions: "40x40 cm",
                materials: "Cerámica y vidrio",
                stock: 5,
                mainImageUrl: "/images/m2.jpg",
                imageUrls: ["/images/m2.jpg"],
                active: true
            },
            {
                id: 2,
                name: "Mosaico Abstracto Azul",
                description: "Diseño abstracto con tonalidades azules vibrantes",
                price: 92000.0,
                category: "MOSAICOS",
                artist: "Carlos Ruiz",
                dimensions: "50x50 cm",
                materials: "Vidrio veneciano",
                stock: 3,
                mainImageUrl: "/images/mosaico2.jpg",
                imageUrls: ["/images/mosaico2.jpg"],
                active: true
            },
            // Agrega aquí los otros 19 productos de tu DataInitializer
            // ... (puedo ayudarte a completar todos si lo necesitas)
        ];
    }

    // Products API
    async getAllProducts() {
        return await this.request('/products');
    }

    async getProductsByCategory(category) {
        return await this.request(`/products/category/${category}`);
    }

    async getProductById(id) {
        return await this.request(`/products/${id}`);
    }

    async searchProducts(query) {
        return await this.request(`/products/search?q=${encodeURIComponent(query)}`);
    }

    async createProduct(product) {
        return await this.request('/products', {
            method: 'POST',
            body: JSON.stringify(product)
        });
    }

    async updateProduct(id, product) {
        return await this.request(`/products/${id}`, {
            method: 'PUT',
            body: JSON.stringify(product)
        });
    }

    async deleteProduct(id) {
        return await this.request(`/products/${id}`, {
            method: 'DELETE'
        });
    }

    // Orders API
    async getAllOrders() {
        return await this.request('/orders');
    }

    async getOrdersByUserId(userId) {
        return await this.request(`/orders/user/${userId}`);
    }

    async getOrderById(id) {
        return await this.request(`/orders/${id}`);
    }

    async createOrder(order) {
        return await this.request('/orders', {
            method: 'POST',
            body: JSON.stringify(order)
        });
    }

    async updateOrderStatus(id, status) {
        return await this.request(`/orders/${id}/status?status=${status}`, {
            method: 'PUT'
        });
    }

    async deleteOrder(id) {
        return await this.request(`/orders/${id}`, {
            method: 'DELETE'
        });
    }
}

// Global API instance
const api = new ApiClient();
const productAPI = new ProductAPI();
// Export for use in other files
window.api = api;