// Cart Management
class Cart {
    constructor() {
        this.items = this.loadCart();
        this.updateCartUI();
    }

    // Load cart from localStorage
    loadCart() {
        const savedCart = localStorage.getItem('artstore_cart');
        return savedCart ? JSON.parse(saved) : [];
    }
//agregado


// Instancia global del carrito

    // Save cart to localStorage
    saveCart() {
        localStorage.setItem('artstore_cart', JSON.stringify(this.items));
    }

    // Add item to cart
    addItem(product, quantity = 1) {
        const existingItem = this.items.find(item => item.productId === product.id);

        if (existingItem) {
            existingItem.quantity += quantity;
            if (existingItem.quantity > product.stock) {
                existingItem.quantity = product.stock;
                this.showNotification('Stock máximo alcanzado', 'warning');
            }
        } else {
            if (quantity > product.stock) {
                quantity = product.stock;
                this.showNotification('Stock máximo alcanzado', 'warning');
            }

            this.items.push({
                productId: product.id,
                name: product.name,
                price: product.price,
                quantity: quantity,
                image: product.mainImageUrl || product.imageUrls?.[0] || '/images/placeholder.jpg',
                maxStock: product.stock
            });
        }

        this.saveCart();
        this.updateCartUI();
        this.showNotification(`${product.name} agregado al carrito`, 'success');
    }

    // Remove item from cart
    removeItem(productId) {
        this.items = this.items.filter(item => item.productId !== productId);
        this.saveCart();
        this.updateCartUI();
        this.showNotification('Producto eliminado del carrito', 'info');
    }

    // Update item quantity
    updateQuantity(productId, quantity) {
        const item = this.items.find(item => item.productId === productId);
        if (item) {
            if (quantity <= 0) {
                this.removeItem(productId);
            } else if (quantity > item.maxStock) {
                item.quantity = item.maxStock;
                this.showNotification('Stock máximo alcanzado', 'warning');
            } else {
                item.quantity = quantity;
            }
            this.saveCart();
            this.updateCartUI();
        }
    }

    // Get total items count
    getTotalItems() {
        return this.items.reduce((total, item) => total + item.quantity, 0);
    }

    // Get total price
    getTotalPrice() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    // Clear cart
    clear() {
        this.items = [];
        this.saveCart();
        this.updateCartUI();
    }

    // Update cart UI
    updateCartUI() {
        this.updateCartCount();
        this.updateCartSidebar();
    }

    // Update cart count badge
    updateCartCount() {
        const cartCount = document.querySelector('.cart-count');
        if (cartCount) {
            const totalItems = this.getTotalItems();
            cartCount.textContent = totalItems;
            cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
        }
    }

    // Update cart sidebar
    updateCartSidebar() {
        const cartItems = document.getElementById('cartItems');
        const cartTotal = document.getElementById('cartTotal');

        if (!cartItems || !cartTotal) return;

        if (this.items.length === 0) {
            cartItems.innerHTML = `
                <div class="empty-cart">
                    <i class="fas fa-shopping-cart" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                    <p>Tu carrito está vacío</p>
                    <p style="color: #666; font-size: 0.9rem;">Agrega algunos productos para empezar</p>
                </div>
            `;
            cartTotal.textContent = '0';
            return;
        }

        cartItems.innerHTML = this.items.map(item => `
            <div class="cart-item" data-product-id="${item.productId}">
                <img src="${item.image}" alt="${item.name}" onerror="this.src='/images/placeholder.jpg'">
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">$${item.price.toLocaleString()}</div>
                    <div class="cart-item-quantity">
                        <button onclick="cart.updateQuantity('${item.productId}', ${item.quantity - 1})">-</button>
                        <span>${item.quantity}</span>
                        <button onclick="cart.updateQuantity('${item.productId}', ${item.quantity + 1})">+</button>
                        <button onclick="cart.removeItem('${item.productId}')" style="margin-left: 1rem; background: #e74c3c;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');

        cartTotal.textContent = this.getTotalPrice().toLocaleString();
    }

    // Show notification
    showNotification(message, type = 'info') {
        // Remove existing notifications
        const existing = document.querySelector('.notification');
        if (existing) {
            existing.remove();
        }

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <span>${message}</span>
                <button onclick="this.parentElement.parentElement.remove()">&times;</button>
            </div>
        `;

        // Add notification styles
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${type === 'success' ? '#27ae60' : type === 'warning' ? '#f39c12' : type === 'error' ? '#e74c3c' : '#3498db'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 9999;
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(notification);

        // Auto remove after 3 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 3000);
    }

    // Open cart sidebar
    openSidebar() {
        const sidebar = document.getElementById('cartSidebar');
        const overlay = document.getElementById('overlay');

        if (sidebar && overlay) {
            sidebar.classList.add('open');
            overlay.classList.add('active');
        }
    }

    // Close cart sidebar
    closeSidebar() {
        const sidebar = document.getElementById('cartSidebar');
        const overlay = document.getElementById('overlay');

        if (sidebar && overlay) {
            sidebar.classList.remove('open');
            overlay.classList.remove('active');
        }
    }

    // Checkout process
    async checkout() {
        if (this.items.length === 0) {
            this.showNotification('El carrito está vacío', 'warning');
            return;
        }

        try {
            // Create order object
            const order = {
                userId: 'guest', // In a real app, this would be the logged-in user ID
                items: this.items.map(item => ({
                    productId: item.productId,
                    productName: item.name,
                    quantity: item.quantity,
                    unitPrice: item.price
                })),
                totalAmount: this.getTotalPrice(),
                shippingAddress: 'Dirección de ejemplo', // This would come from a form
                paymentMethod: 'Tarjeta de crédito',
                notes: ''
            };

            // Create order via API
            const result = await api.createOrder(order);

            this.showNotification('¡Pedido realizado con éxito!', 'success');
            this.clear();
            this.closeSidebar();

            // In a real app, redirect to order confirmation page
            console.log('Order created:', result);

        } catch (error) {
            console.error('Checkout error:', error);
            this.showNotification('Error al procesar el pedido. Intenta nuevamente.', 'error');
        }
    }
}

// Create global cart instance
const cart = new Cart();

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .notification-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 1rem;
    }
    
    .notification-content button {
        background: none;
        border: none;
        color: white;
        font-size: 1.2rem;
        cursor: pointer;
        padding: 0;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .empty-cart {
        text-align: center;
        padding: 2rem;
        color: #666;
    }
`;
document.head.appendChild(style);

// Export cart for global use
window.cart = cart;