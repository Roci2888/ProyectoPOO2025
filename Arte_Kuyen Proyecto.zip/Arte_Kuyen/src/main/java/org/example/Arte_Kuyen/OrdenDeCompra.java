package org.example.Arte_Kuyen;

import java.time.LocalDate;
import java.util.List;

public class OrdenDeCompra {
    private int id;
    Usuario usuario;
    Carrito carrito;
    Transaccion transaccion;

    public OrdenDeCompra(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public void mostrarOrdenDeCompra(Transaccion transaccion) {
        System.out.println("ID: " + transaccion.getId());
        System.out.println("Banco: " + transaccion.getBanco());
        System.out.println("Fecha_Hora: "+ transaccion.getFecha_hora());
        System.out.println("Monto: "+ transaccion.getMonto(carrito));
    }

    @Override
    public String toString() {
        return "OrdenDeCompra{" +
                "id=" + id +
                ", usuario=" + usuario +
                ", carrito=" + carrito +
                ", transaccion=" + transaccion +
                '}';
    }
}
