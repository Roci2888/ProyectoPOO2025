package org.example.Arte_Kuyen.repositories;

import com.mongodb.ConnectionString;
import com.mongodb.MongoException;
import com.mongodb.client.ListDatabasesIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import org.bson.BsonDocument;
import org.bson.BsonInt64;
import org.bson.Document;
import org.bson.conversions.Bson;

public class ConexionMongoDB {
    private final ConnectionString conexion;
    private MongoClient mongoClient;

    public ConexionMongoDB(String host, int port, String usuario, String contrasena) {
        String uri = String.format("mongodb://%s:%s@%s:%d/", usuario, contrasena, host, port);
        this.conexion = new ConnectionString(uri);
        this.mongoClient = null;
    }

    public boolean crearConexion() throws MongoException {
        try {
            MongoClient mongoClient1 = MongoClients.create(conexion);
            MongoDatabase database = mongoClient1.getDatabase("Arte_Kuyen");
            Bson comando = new BsonDocument("ping", new BsonInt64(1));
            Document resultado = database.runCommand(comando);
            System.out.println("La conexion con la base de datos ha sido establecida, Ping: " + resultado.toString());
            this.mongoClient = mongoClient1;

            return true;
        } catch (MongoException e) {
            System.out.println("Error" + e.getMessage());
            throw e;
        }
    }

    public void mostrarInformacionCluster() {
        if (this.mongoClient == null) {
            System.out.println("No hay conexion con la base de datos");
            return;
        }
        System.out.println("Informacion del cluster");
        System.out.println(this.mongoClient.getClusterDescription());
    }

    public void mostrarBasesDeDatos() {
        if (this.mongoClient == null) {
            System.out.println("No hay conexion con la base de datos");
            return;
        }
        System.out.println("Listado de bases de datos");

        ListDatabasesIterable<Document> databases = this.mongoClient.listDatabases();
        int i = 1;
        for (Document document : databases) {
            System.out.println(String.format("%d-) %s", i, document.toString()));
            i++;
        }
    }

    public void cerrarConexion() {
        if (this.mongoClient != null) {
            this.mongoClient.close();
            System.out.println("Se ha cerrado la conexion con MongoDB");
        }
    }


}