package org.example.Arte_Kuyen;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class UsuarioApplication {
    public static void main(String[] args) {
        SpringApplication.run(UsuarioApplication.class, args);
        ArrayList<Usuario> usuarios = importarUsuarios();
       usuarios.forEach(System.out::println);
    }

    private static ArrayList<Usuario> importarUsuarios() {
        JsonParser jsonParser = new JsonParser();
        ArrayList<Usuario> objs = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader("usuarios.json"));
            JsonElement jsonElement = jsonParser.parse(br);
            objs = new Gson().fromJson(jsonElement, new
                    TypeToken<List<Usuario>>() {
                    }.getType());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return objs;
    }
}
