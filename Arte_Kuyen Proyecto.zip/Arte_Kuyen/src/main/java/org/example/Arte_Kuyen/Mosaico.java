package org.example.Arte_Kuyen;

public class Mosaico extends Articulo{

    public Mosaico(int id, String nombre, String descripcion, int precio) {
        super(id, nombre, descripcion, precio);
    }

    @Override
    public String toString() {
        return "Mosaico{}";
    }
}
