package org.example.Arte_Kuyen;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Pago {
    private int id;
    private String medio;
    private LocalDateTime fecha_hora;
    private boolean estado;

    public Pago(int id, String medio, LocalDateTime fecha_hora, boolean estado) {
        this.id = id;
        this.medio = medio;
        this.fecha_hora = fecha_hora;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isEstado() {
        return estado;
    }

    @Override
    public String toString() {
        return "Pago{" +
                "id=" + id +
                ", medio='" + medio + '\'' +
                ", fecha_hora=" + fecha_hora +
                ", estado=" + estado +
                '}';
    }
}
