package org.example.Arte_Kuyen;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.mongodb.MongoException;
import org.example.Arte_Kuyen.repositories.ConexionMongoDB;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class ArteKuyenApplication {

    public static void main(String[] args) {
        SpringApplication.run(ArteKuyenApplication.class, args);

    }

}

