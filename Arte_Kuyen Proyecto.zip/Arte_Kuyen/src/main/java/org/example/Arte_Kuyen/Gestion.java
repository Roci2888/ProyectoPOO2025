package org.example.Arte_Kuyen;

public interface Gestion {

    void ventasPorDia();
    void articulosOrdenadosPorStock();
    void sumaBoletas();

}
