package org.example.Arte_Kuyen;

import java.time.LocalDateTime;

public class Transaccion {
    private int id;
    private String banco;
    private LocalDateTime fecha_hora;
    private double monto;

    public Transaccion(int id, String banco, LocalDateTime fecha_hora, double monto) {
        this.id = id;
        this.banco = banco;
        this.fecha_hora = fecha_hora;
        this.monto = monto;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBanco() {
        return banco;
    }

    public LocalDateTime getFecha_hora() {
        return fecha_hora;
    }

    public double getMonto(Carrito carrito) {
        return carrito.calcularTotal();
    }

    public void verificacionPago(Pago pago) {
        if (pago.isEstado() == true) {
            System.out.println("Pago verificado");
        } else {
            System.out.println("El pago no se ha efectuado, no fue posible la transaccion");
        }
    }

    @Override
    public String toString() {
        return "Transaccion{" +
                "id=" + id +
                ", banco='" + banco + '\'' +
                ", fecha_hora=" + fecha_hora +
                ", monto=" + monto +
                '}';
    }
}
