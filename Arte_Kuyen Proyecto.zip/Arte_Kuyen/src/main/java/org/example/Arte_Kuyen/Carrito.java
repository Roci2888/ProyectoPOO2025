package org.example.Arte_Kuyen;

import java.util.List;

public class Carrito {
    List<Articulo> articulos;
    private int id;
    Usuario usuario;
    private double total;

    public Carrito(int id, Usuario usuario) {
        this.id = id;
        this.usuario = usuario;
    }

    public void setTotal() {
        this.total = calcularTotal();
    }

    public void eliminarArticulo(Articulo articulo) {
this.articulos.remove(articulo);
    }

    public double calcularTotal() {
        if (articulos == null || articulos.isEmpty()) {
            return 0.0;
        }

        return articulos.stream()
                .mapToDouble(Articulo::getPrecio)
                .sum();
    }

    @Override
    public String toString() {
        return "Carrito{" +
                "articulos=" + articulos +
                ", id=" + id +
                ", usuario=" + usuario +
                '}';
    }
}
