// Main Application Logic
class ArtStoreApp {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentCategory = 'all';
        this.currentSearchTerm = '';
        this.currentPriceFilter = 'all';

        this.init();
    }

    async init() {
        this.setupEventListeners();
        await this.loadProducts();
        this.renderProducts();
    }

    setupEventListeners() {
        // Navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const category = e.target.dataset.category;
                this.filterByCategory(category);
                this.updateActiveNavLink(e.target);
            });
        });

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            let searchTimeout;
            searchInput.addEventListener('input', (e) => {
                clearTimeout(searchTimeout);
                searchTimeout = setTimeout(() => {
                    this.currentSearchTerm = e.target.value.trim();
                    this.filterProducts();
                }, 300);
            });
        }

        // Price filter
        const priceFilter = document.getElementById('priceFilter');
        if (priceFilter) {
            priceFilter.addEventListener('change', (e) => {
                this.currentPriceFilter = e.target.value;
                this.filterProducts();
            });
        }

        // Cart icon click
        const cartIcon = document.querySelector('.cart-icon');
        if (cartIcon) {
            cartIcon.addEventListener('click', () => {
                cart.openSidebar();
            });
        }

        // Cart sidebar close
        const closeCart = document.querySelector('.close-cart');
        if (closeCart) {
            closeCart.addEventListener('click', () => {
                cart.closeSidebar();
            });
        }

        // Overlay click
        const overlay = document.getElementById('overlay');
        if (overlay) {
            overlay.addEventListener('click', () => {
                cart.closeSidebar();
                this.closeProductModal();
            });
        }

        // Checkout button
        const checkoutBtn = document.getElementById('checkoutBtn');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', () => {
                cart.checkout();
            });
        }

        // Modal close
        const modalClose = document.querySelector('.modal .close');
        if (modalClose) {
            modalClose.addEventListener('click', () => {
                this.closeProductModal();
            });
        }

        // CTA button
        const ctaButton = document.querySelector('.cta-button');
        if (ctaButton) {
            ctaButton.addEventListener('click', () => {
                document.querySelector('.main-content').scrollIntoView({
                    behavior: 'smooth'
                });
            });
        }
    }

    async loadProducts() {
        try {
            this.showLoading(true);
            this.products = await api.getAllProducts();
            this.filteredProducts = [...this.products];
        } catch (error) {
            console.error('Error loading products:', error);
            this.showError('Error al cargar los productos. Por favor, intenta nuevamente.');
        } finally {
            this.showLoading(false);
        }
    }

    filterByCategory(category) {
        this.currentCategory = category;
        this.filterProducts();
    }

    filterProducts() {
        let filtered = [...this.products];

        // Filter by category
        if (this.currentCategory !== 'all') {
            filtered = filtered.filter(product =>
                product.category === this.currentCategory
            );
        }

        // Filter by search term
        if (this.currentSearchTerm) {
            const searchLower = this.currentSearchTerm.toLowerCase();
            filtered = filtered.filter(product =>
                product.name.toLowerCase().includes(searchLower) ||
                (product.description && product.description.toLowerCase().includes(searchLower)) ||
                (product.artist && product.artist.toLowerCase().includes(searchLower))
            );
        }

        // Filter by price
        if (this.currentPriceFilter !== 'all') {
            filtered = filtered.filter(product => {
                const price = product.price;
                switch (this.currentPriceFilter) {
                    case '0-50000':
                        return price <= 50000;
                    case '50000-100000':
                        return price > 50000 && price <= 100000;
                    case '100000-200000':
                        return price > 100000 && price <= 200000;
                    case '200000+':
                        return price > 200000;
                    default:
                        return true;
                }
            });
        }

        this.filteredProducts = filtered;
        this.renderProducts();
    }

    renderProducts() {
        const productsGrid = document.getElementById('productsGrid');
        const noResults = document.getElementById('noResults');

        if (!productsGrid || !noResults) return;

        if (this.filteredProducts.length === 0) {
            productsGrid.style.display = 'none';
            noResults.style.display = 'block';
            return;
        }

        noResults.style.display = 'none';
        productsGrid.style.display = 'grid';

        productsGrid.innerHTML = this.filteredProducts.map(product => `
            <div class="product-card" onclick="app.openProductModal('${product.id}')">
                <img 
                    class="product-image" 
                    src="${product.mainImageUrl || product.imageUrls?.[0] || '/images/placeholder.jpg'}" 
                    alt="${product.name}"
                    onerror="this.src='/images/placeholder.jpg'"
                >
                <div class="product-info">
                    <h3 class="product-name">${product.name}</h3>
                    <p class="product-price">$${product.price.toLocaleString()}</p>
                    <p class="product-description">${product.description || 'Sin descripción disponible'}</p>
                    <span class="product-category">${this.getCategoryDisplayName(product.category)}</span>
                    ${product.stock <= 0 ? '<div class="out-of-stock">Agotado</div>' : ''}
                </div>
            </div>
        `).join('');
    }

    getCategoryDisplayName(category) {
        const categoryMap = {
            'MOSAICOS': 'Mosaicos',
            'CUADROS': 'Cuadros',
            'JOYAS': 'Joyas'
        };
        return categoryMap[category] || category;
    }

    async openProductModal(productId) {
        try {
            const product = await api.getProductById(productId);
            this.showProductModal(product);
        } catch (error) {
            console.error('Error loading product details:', error);
            this.showError('Error al cargar los detalles del producto.');
        }
    }

    showProductModal(product) {
        const modal = document.getElementById('productModal');
        if (!modal) return;

        // Update modal content
        document.getElementById('modalMainImage').src = product.mainImageUrl || product.imageUrls?.[0] || '/images/placeholder.jpg';
        document.getElementById('modalProductName').textContent = product.name;
        document.getElementById('modalProductPrice').textContent = `$${product.price.toLocaleString()}`;
        document.getElementById('modalProductDescription').textContent = product.description || 'Sin descripción disponible';
        document.getElementById('modalProductArtist').textContent = product.artist || 'No especificado';
        document.getElementById('modalProductDimensions').textContent = product.dimensions || 'No especificado';
        document.getElementById('modalProductMaterials').textContent = product.materials || 'No especificado';
        document.getElementById('modalProductStock').textContent = product.stock || '0';

        // Reset quantity
        const quantityInput = document.getElementById('quantity');
        if (quantityInput) {
            quantityInput.value = 1;
            quantityInput.max = product.stock;
        }

        // Setup quantity controls
        this.setupQuantityControls(product);

        // Setup add to cart button
        const addToCartBtn = document.getElementById('addToCartBtn');
        if (addToCartBtn) {
            addToCartBtn.onclick = () => {
                const quantity = parseInt(quantityInput.value) || 1;
                cart.addItem(product, quantity);
                this.closeProductModal();
            };

            // Disable if out of stock
            if (product.stock <= 0) {
                addToCartBtn.disabled = true;
                addToCartBtn.innerHTML = '<i class="fas fa-times"></i> Agotado';
            } else {
                addToCartBtn.disabled = false;
                addToCartBtn.innerHTML = '<i class="fas fa-shopping-cart"></i> Agregar al Carrito';
            }
        }

        modal.style.display = 'block';
    }

    setupQuantityControls(product) {
        const quantityInput = document.getElementById('quantity');
        const decreaseBtn = document.getElementById('decreaseQty');
        const increaseBtn = document.getElementById('increaseQty');

        if (!quantityInput || !decreaseBtn || !increaseBtn) return;

        decreaseBtn.onclick = () => {
            const currentValue = parseInt(quantityInput.value) || 1;
            if (currentValue > 1) {
                quantityInput.value = currentValue - 1;
            }
        };

        increaseBtn.onclick = () => {
            const currentValue = parseInt(quantityInput.value) || 1;
            if (currentValue < product.stock) {
                quantityInput.value = currentValue + 1;
            }
        };

        quantityInput.addEventListener('change', () => {
            let value = parseInt(quantityInput.value) || 1;
            if (value < 1) value = 1;
            if (value > product.stock) value = product.stock;
            quantityInput.value = value;
        });
    }

    closeProductModal() {
        const modal = document.getElementById('productModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    updateActiveNavLink(activeLink) {
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        activeLink.classList.add('active');
    }

    showLoading(show) {

        const loading = document.getElementById('loading');
        const productsGrid = document.getElementById('productsGrid');

        if (loading) {
            loading.style.display = show ? 'block' : 'none';
        }
        if (productsGrid) {
            productsGrid.style.display = show ? 'none' : 'grid';
        }
    }





    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.innerHTML = `
            <div style="
                background: #e74c3c;
                color: white;
                padding: 1rem;
                border-radius: 8px;
                margin: 1rem 0;
                text-align: center;
            ">
                <i class="fas fa-exclamation-triangle"></i>
                ${message}
            </div>
        `;

        const container = document.querySelector('.container');
        if (container) {
            container.insertBefore(errorDiv, container.firstChild);

            setTimeout(() => {
                errorDiv.remove();
            }, 5000);
        }
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ArtStoreApp();
});

// Export for global use
window.ArtStoreApp = ArtStoreApp;