package org.example.Arte_Kuyen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArteKuyenApplicationTests {

	@Test
	void contextLoads() {
	}

}
