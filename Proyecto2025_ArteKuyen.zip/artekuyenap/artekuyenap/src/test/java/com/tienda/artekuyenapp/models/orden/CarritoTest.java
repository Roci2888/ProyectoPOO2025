package com.tienda.artekuyenapp.models.orden;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.assertj.core.api.Assertions.assertThat;

class CarritoTest {

    private Carrito carrito;
    private List<ItemCarrito> itemsDePrueba;

    @BeforeEach
    void setUp() {
        System.out.println("=== Inicializando prueba con datos reales de DB ===");

        itemsDePrueba = new ArrayList<>();

        carrito = new Carrito("INVITADO");
        carrito.setItems(itemsDePrueba);
        carrito.setId("693383ed572f947a4eb68d6d");
    }

    @AfterEach
    void tearDown() {
        System.out.println("=== Limpieza de datos de prueba ===");
        carrito = null;
        itemsDePrueba = null;
    }

    @Nested
    @DisplayName("Pruebas basadas en datos reales de MongoDB")
    class PruebasConDatosReales {

        @Test
        @DisplayName("Carrito de INVITADO tiene datos correctos según DB")
        void carritoInvitado_TieneDatosCorrectos() {
            // Assert
            assertEquals("INVITADO", carrito.getUsuarioId());
            assertEquals("693383ed572f947a4eb68d6d", carrito.getId());
            assertEquals(4, carrito.getItems().size());

            // Verificar primer item
            ItemCarrito primerItem = carrito.getItems().get(0);
            assertEquals("69335394f7921ee963a540c9", primerItem.getProductoId());
            assertEquals("Collar Luna y Estrella", primerItem.getNombre());
            assertEquals("FISICO", primerItem.getTipo());
            assertEquals(1, primerItem.getCantidad());
            assertEquals(25000, primerItem.getPrecioUnitario());
            assertEquals(25000, primerItem.getSubtotal());
        }
    }

    @Nested
    @DisplayName("Pruebas con diferentes usuarios de DB")
    class PruebasMultiplesUsuarios {

        @Test
        @DisplayName("Crear carrito para usuario 432A8691B7F51208F820B0268F6A53BC")
        void carritoUsuarioEncriptado_CreadoCorrectamente() {
            Carrito carritoUsuario2 = new Carrito("432A8691B7F51208F820B0268F6A53BC");
            carritoUsuario2.setId("69361b6be6a21d5b78b4228b");

            List<ItemCarrito> itemsUsuario2 = new ArrayList<>();


            carritoUsuario2.setItems(itemsUsuario2);

            assertEquals("432A8691B7F51208F820B0268F6A53BC", carritoUsuario2.getUsuarioId());
            assertEquals(4, carritoUsuario2.getItems().size());// 25000+90000+10000+60000
        }

        @Test
        @DisplayName("Carrito vacío para usuario 6935adf781886a753d8ee611")
        void carritoVacio_UsuarioSinItems() {
            Carrito carritoVacio = new Carrito("6935adf781886a753d8ee611");
            carritoVacio.setId("693653ea3e0e4d37399e6b45");
            carritoVacio.setItems(new ArrayList<>());

            assertEquals("6935adf781886a753d8ee611", carritoVacio.getUsuarioId());
            assertTrue(carritoVacio.getItems().isEmpty());
        }

        @ParameterizedTest
        @CsvSource({
                "INVITADO, 693383ed572f947a4eb68d6d, 4, 385000",
                "432A8691B7F51208F820B0268F6A53BC, 69361b6be6a21d5b78b4228b, 4, 185000",
                "6936533b7baf8751b9e9c539, 6936534b7baf8751b9e9c53a, 2, 105000",
                "6934d14e1e89806e9e8aec84, 693659bafd20637a06581707, 2, 85000"
        })
        @DisplayName("Pruebas parametrizadas con todos los usuarios de DB")
        void testTodosLosUsuariosDB(String usuarioId, String carritoId, int cantidadItems, double totalEsperado) {
            Carrito carrito = new Carrito(usuarioId);
            carrito.setId(carritoId);

            List<ItemCarrito> items = new ArrayList<>();

            carrito.setItems(items);

            assertEquals(usuarioId, carrito.getUsuarioId());
            assertEquals(carritoId, carrito.getId());
            assertEquals(cantidadItems, carrito.getItems().size());
        }
    }

    @Nested
    @DisplayName("Pruebas de edge cases y validaciones")
    class PruebasEdgeCases {


        @Test
        @DisplayName("Carrito con items null maneja correctamente")
        void carritoConItemsNull_NoLanzaExcepcion() {
            Carrito carritoNulo = new Carrito("test");
            carritoNulo.setItems(null);

            assertNotNull(carritoNulo.getItems());
            assertTrue(carritoNulo.getItems().isEmpty());
        }
    }

    @Test
    @DisplayName("Prueba de integridad con AssertJ - Usando datos reales")
    void pruebaIntegridadConAssertJ() {
        assertThat(carrito)
                .isNotNull()
                .hasFieldOrPropertyWithValue("usuarioId", "INVITADO")
                .hasFieldOrPropertyWithValue("id", "693383ed572f947a4eb68d6d");

        assertThat(carrito.getItems())
                .isNotEmpty()
                .hasSize(4)
                .extracting(ItemCarrito::getNombre)
                .containsExactly(
                        "Collar Luna y Estrella",
                        "Ilustración",
                        "Cuadro Atardecer",
                        "Mosaico Azul 40x40"
                );
    }
}
