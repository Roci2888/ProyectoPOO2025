package com.tienda.artekuyenapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtekuyenappApplicationTests {

	@Test
	void contextLoads() {
	}

}
