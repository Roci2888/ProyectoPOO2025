package com.tienda.artekuyenapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtekuyenappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtekuyenappApplication.class, args);
	}

}
