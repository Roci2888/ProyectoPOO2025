package com.tienda.artekuyenapp.models.usuario;

public enum Rol {
    ADMIN,
    CLIENTE
}
