package com.tienda.artekuyenapp.models.productos;

public enum CategoriaProducto {
    MOSAICO,
    CUADRO,
    JOYA
}
